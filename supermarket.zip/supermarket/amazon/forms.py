from django import forms
from .models import User
from django.core import validators
class ProductRegistration(forms.ModelForm):
    class Meta:
        model = User
        fields = ['Prodid', 'Prodname', 'Prodtype1', 'Price', 'Prodtype2']
        widgets = {
            'Prodid': forms.TextInput(attrs={'class': 'form-control'}),
            'Prodname': forms.TextInput(attrs={'class':'form-control'}),
            'Prodtype1': forms.TextInput(attrs={'class': 'form-control'}),
            'Price': forms.TextInput(attrs={'class': 'form-control'}),
            'Prodtype2': forms.TextInput(attrs={'class': 'form-control'}),
        }