from django.db import models
# Create your models here.
class User(models.Model):
    Prodid = models.CharField(max_length=70)
    Prodname = models.CharField(max_length=100)
    Prodtype1 = models.CharField(max_length=100)
    Price = models.CharField(max_length=100)
    Prodtype2 = models.CharField(max_length=100)