from django.shortcuts import render, HttpResponseRedirect
from .forms import ProductRegistration
from .models import User
# Create your views here.
#adding and retrieving data
def add_show(request):
    if request.method == 'POST':
        fm = ProductRegistration(request.POST)
        if fm.is_valid():
            id = fm.cleaned_data['Prodid']
            nm = fm.cleaned_data['Prodname']
            ty = fm.cleaned_data['Prodtype1']
            pr = fm.cleaned_data['Price']
            Ty = fm.cleaned_data['Prodtype2']
            reg = User( Prodid=id, Prodname=nm, Prodtype1=ty, Price=pr, Prodtype2=Ty)
            reg.save()
            fm = ProductRegistration()
    else:
        fm = ProductRegistration()
    prod = User.objects.all()
    return render(request, 'amazon/add.html', {'form':fm, 'pro':prod})
#edit and update function
def update_data(request,id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        fm = ProductRegistration(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = User.objects.get(pk=id)
        fm = ProductRegistration(instance=pi)
    return render(request,'amazon/update.html', {'form':fm})
#delete function
def delete_data(request,id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')